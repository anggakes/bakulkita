<?php
/*
 * Portfolio post type.
 */

if( ! class_exists( 'Custom_Post_Type' ) ) {

	class Custom_Post_Type {

		public function __construct() {
			add_action('init', array($this, 'hawa_register_portfolio'), 0);
		}

		public function hawa_register_portfolio() {
			$post_type_labels       = array(
				'name'                => 'Portfolios',
				'singular_name'       => 'Portfolio',
				'menu_name'           => 'Portfolio',
				'parent_item_colon'   => 'Parent Item:',
				'all_items'           => 'All Portfolios',
				'view_item'           => 'View Item',
				'add_new_item'        => 'Add New Item',
				'add_new'             => 'Add New',
				'edit_item'           => 'Edit Item',
				'update_item'         => 'Update Item',
				'search_items'        => 'Search portfolios',
				'not_found'           => 'No portfolios found',
				'not_found_in_trash'  => 'No portfolios found in Trash',
			);

			$post_type_rewrite      = array(
				'slug'                => 'portfolio-item',
				'with_front'          => true,
				'pages'               => true,
				'feeds'               => true,
			);

			$post_type_args         = array(
				'label'               => 'portfolio',
				'description'         => 'Portfolio information pages',
				'labels'              => $post_type_labels,
				'supports'            => array( 'editor', 'title', 'thumbnail', 'comments' ),
				'taxonomies'          => array( 'post' ),
				'hierarchical'        => false,
				'public'              => true,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_nav_menus'   => true,
				'show_in_admin_bar'   => true,
				'can_export'          => true,
				'has_archive'         => true,
				'exclude_from_search' => true,
				'publicly_queryable'  => true,
				'rewrite'             => $post_type_rewrite,
				'capability_type'     => 'post',
			);
			register_post_type( 'portfolio', $post_type_args );

			$taxonomy_labels                = array(
				'name'                        => 'Category',
				'singular_name'               => 'Category',
				'menu_name'                   => 'Categories',
				'all_items'                   => 'All Categories',
				'parent_item'                 => 'Parent Category',
				'parent_item_colon'           => 'Parent Category:',
				'new_item_name'               => 'New Category Name',
				'add_new_item'                => 'Add New Category',
				'edit_item'                   => 'Edit Category',
				'update_item'                 => 'Update Category',
				'separate_items_with_commas'  => 'Separate categories with commas',
				'search_items'                => 'Search categories',
				'add_or_remove_items'         => 'Add or remove categories',
				'choose_from_most_used'       => 'Choose from the most used categories',
			);

			$taxonomy_rewrite         = array(
				'slug'                  => 'portfolio-category',
				'with_front'            => true,
				'hierarchical'          => true,
			);

			$taxonomy_args          = array(
				'labels'              => $taxonomy_labels,
				'hierarchical'        => true,
				'public'              => true,
				'show_ui'             => true,
				'show_admin_column'   => true,
				'show_in_nav_menus'   => true,
				'show_tagcloud'       => true,
				'rewrite'             => $taxonomy_rewrite,
			);
			register_taxonomy( 'portfolio-category', 'portfolio', $taxonomy_args );

			$taxonomy_tags_args     = array(
				'hierarchical'        => false,
				'show_admin_column'   => true,
				'rewrite'             => 'portfolio-tag',
				'label'               => 'Tags',
				'singular_label'      => 'Tags',
			);
			register_taxonomy( 'portfolio-tag', array('portfolio'), $taxonomy_tags_args );

		} //end of register portfolio

	} // end of class

	new Custom_Post_Type;
} // end of class_exists

add_action('init', 'wpc_register_post_type_and_tax' );
function wpc_register_post_type_and_tax() { 
	// New Post Type
	register_post_type( 'restaurant',
		array(
			'labels' => array(
				'name' 			=> __( 'Restaurant menu' ),
				'singular_name' => __( 'Item' )
			),
			'menu_icon'   => 'dashicons-welcome-view-site',
			'public'      => true,
			'has_archive' => true,
			'supports'    => array( 'editor', 'title', 'thumbnail' ),
			'rewrite' 	  => array('slug' => 'restaurant'),
		)
	);
	// New Taxonomy
	register_taxonomy(
		'restaurant-category',
		'restaurant',
		array(
			'label' 	   => __( 'Categories' ),
			'rewrite' 	   => array( 'slug' => 'restaurant-category' ),
			'hierarchical' => true,
		)
	);
	//end of register
}