<?php 
/*
 * Map Shortcode
 * Author: QodeArena
 * Author URI: http://qodearena.com/
 * Version: 1.0.0 
 */

vc_map(
	array(
		'name'        => __( 'Google Map', 'js_composer' ),
		'base'        => 'antica_map',
		'params'      => array(
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Latitude', 'js_composer' ),
				'admin_label' => true,
				'param_name'  => 'latitude'
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Longitude', 'js_composer' ),
				'admin_label' => true,
				'param_name'  => 'longitude'
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Zoom', 'js_composer' ),
				'param_name'  => 'zoom',
				'description' => 'Map zooming value. Max - 19, min - 0.',
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Marker text', 'js_composer' ),
				'param_name'  => 'text'
			),
			array(
				'heading' 	  => __( 'Map marker', 'js_composer' ),
				'type' 		  => 'dropdown',
				'param_name'  => 'marker',
				'value' 	  => array(
					__( 'Default', 'js_composer' ) => 'default',
					__( 'Custom', 'js_composer' )  => 'custom'
				)
			),
			array(
				'type'        => 'attach_image',
				'heading'     => __( 'Marker image', 'js_composer' ),
				'param_name'  => 'marker_image',
				'dependency'  => array( 'element' => 'marker', 'value' => 'custom' )
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Custom map height', 'js_composer' ),
				'param_name'  => 'height',
				'group' 	  => __( 'Style Map', 'js_composer' ),
				'description' => 'By default 550px.'
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Style Map', 'js_composer' ),
				'param_name' => 'style',
				'value' => array(
					__( 'Default', 'js_composer' ) 	   => '',
					__( 'Theme style', 'js_composer' ) => 'style-1',
					__( 'Custom', 'js_composer' )  	   => 'custom',
				),
				'group' => __( 'Style Map', 'js_composer' ),
				'description' => __( 'Select stretching options for row and content (Note: stretched may not work properly if parent container has "overflow: hidden" CSS property).', 'js_composer' ),
			),
			array(
			  'type' => 'textarea_raw_html',
			  'heading' => __( 'Code Style Map', 'js_composer' ),
			  'param_name' => 'content',
			  'value' => '',
			  'description' => 'Enter your style for map. Yo can find diferent style there <a href="https://snazzymaps.com">snazzymaps.com</a>',
			  'dependency' => array(
			  	'element' => 'style',
			  	'value' => array( 'custom' ),
			  ),
			  'group' => __( 'Style Map', 'js_composer' )
			),
			array(
				'type' 		  => 'textfield',
				'heading' 	  => __( 'Extra class name', 'js_composer' ),
				'param_name'  => 'el_class',
				'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
				'value' 	  => ''
			),
			/* CSS editor */
			array(
				'type' 		  => 'css_editor',
				'heading' 	  => __( 'CSS box', 'js_composer' ),
				'param_name'  => 'css',
				'group' 	  => __( 'Design options', 'js_composer' )
			)
		)
	)
);

class WPBakeryShortCode_antica_map extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
		    'latitude' 	   => '',
		    'longitude'    => '',
		    'zoom' 		   => '',
		    'text' 		   => '',
		    'marker' 	   => 'default',
		    'marker_image' => '',
		    'style'        => '',
		    'height'       => '',
		    'el_class' 	   => '',
		    'css' 		   => '',
		), $atts ) );

		if( is_numeric( $latitude ) and is_numeric( $longitude ) ) {

			$class  = ( ! empty( $el_class ) ) ? $el_class : '';
			$class .= vc_shortcode_custom_css_class( $css, ' ' );

		    $marker = ( $marker == 'default' ) ? get_template_directory_uri() . '/assets/img/marker-map.png' : wp_get_attachment_url( $marker_image );

		    $map_zoom = ( ! empty( $zoom ) && is_numeric( $zoom) ) ? $zoom : 10;

		    // custom style map
		    $script = '';
		    if ( $style == 'custom' && $content != '' ) {
		    	$content = rawurldecode( base64_decode( strip_tags( $content ) ) );
		    	$script = '<script> var antica_style_map = ' . $content . ';</script>';
		    }

		    /* Custom map height */
		    $css_style = '';
		    if( ! empty( $height ) ) {
		    	$height = is_numeric( $height ) ? $height . 'px' : $height;
		    	$css_style = 'style="height:' . $height . ';"';
		    }

		    return '<div id="map"
		    	' . $css_style . ' 
		      	class="' . $class . '"
		      	data-lat="' . $latitude . '" 
		      	data-lng="' . $longitude . '" 
		      	data-string="' . $text . '" 
		      	data-marker="' . $marker . '" 
		     	data-zoom="' . $map_zoom . '" 
		      	data-style="' . $style . '"
		    ></div>' . $script;
		}
	}
}