<?php 
/*
 * Process Shortcode
 * Author: QodeArena
 * Author URI: http://qodearena.com/
 * Version: 1.0.0 
 */

vc_map( 
	array(
		'name'                    => __( 'Process Block', 'js_composer' ),
		'base'                    => 'antica_process',
		'as_parent' 		      => array('only' => 'antica_process_item'),
		'content_element'         => true,
		'show_settings_on_create' => false,
		'js_view'                 => 'VcColumnView',
		'params'          		  => array(
			array(
				'type'        => 'dropdown',
				'heading'     => __( 'Item columns size', 'js_composer' ),
				'param_name'  => 'columns',
				'value'       => array(
					'5 columns' => '1/5',
					'4 columns' => '1/4',
					'3 columns' => '1/3',
					'2 columns' => '1/2',
				)
			),
			array(
				'type'        => 'checkbox',
				'heading'     => __( 'Seperator Block', 'js_composer' ),
				'param_name'  => 'seperator_block'
			),
			array(
				'type' 		  => 'textfield',
				'heading' 	  => __( 'Extra class name', 'js_composer' ),
				'param_name'  => 'el_class',
				'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
				'value' 	  => ''
			),
			array(
				'type' 		  => 'css_editor',
				'heading' 	  => __( 'CSS box', 'js_composer' ),
				'param_name'  => 'css',
				'group' 	  => __( 'Design options', 'js_composer' )
			)
		) //end params
	)
);

class WPBakeryShortCode_antica_process extends WPBakeryShortCodesContainer {
	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'columns'  		   => '1/5',
			'seperator_block'  => false,
			'css'	   		   => '',
			'el_class' 		   => ''
		), $atts ) );

		$class  = ( ! empty( $el_class ) ) ? $el_class : '';
		$class .= vc_shortcode_custom_css_class( $css, ' ' );
		$output = '';

		global $antica_process_items;
		$antica_process_items = '';

		do_shortcode( $content );

		// Column process item
		if ( function_exists('wpb_translateColumnWidthToSpan') ) {
			if( $columns == '1/5' ) {
				$width_class = 'col-5';
			} else {
				$width_class = wpb_translateColumnWidthToSpan( $columns );
			}
		}

		// Seperator block
		$seperator_block = ( isset( $seperator_block ) && $seperator_block == 'true' ) ? 'border' : '';

		if( ! empty( $antica_process_items ) && count( $antica_process_items ) > 0 ) {

			$output = '';
			$output .= '<div class="process ' . $seperator_block . ' clearfix ' . $class . '">';
			
			foreach ( $antica_process_items as $key => $item ) {
				$value = (object) $item['atts'];

				// Title process item
				$title = ( ! empty( $value->title ) ) ? $value->title : '';
				$title_color = ( ! empty( $value->title_color ) ) ? $value->title_color : '';
				if( $title_color == 'light' ) {
					$color_title = 'light';
				} else {
					$color_title = 'dark';
				}

				// Number process item
				$number = ( ! empty( $value->number ) ) ? $value->number : '';

				// Seperator process item
				$seperator = ( isset( $value->seperator_item ) && $value->seperator_item == 'true' ) ? 'seperator' : '';
				
				// Procent process item
				$procent   = ( isset( $value->procent ) && $value->procent == 'true' ) ? '%' : '';

				// Process Item			
	            $output .= '<div class="' . $width_class . '">';
		            $output .= '<div class=" process-item ' . $seperator . '">';
		                $output .= '<h2><span data-to="' . $number . '"  data-from="0"  data-speed="1000" >' . $number . '</span>' . $procent . '</h2>';
		                $output .= '<span class="title ' . $color_title . '">' . $title . '</span>';
		            $output .= '</div>';
	            $output .= '</div>';


			}	
			
			$output .= '</div>';

		}

		return $output;
	}
}

vc_map( 
	array(
		'name'            => 'Item',
		'base'            => 'antica_process_item',
		'as_child' 		  => array('only' => 'antica_process'),
		'content_element' => true,
		'params'          => array(
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Title', 'js_composer' ),
				'admin_label' => true,
				'param_name'  => 'title'
			),
			array(
				'type'        => 'dropdown',
				'heading'     => __( 'Title color', 'js_composer' ),
				'param_name'  => 'title_color',
				'value'       => array(
					__( 'Dark' )   => 'dark',
					__( 'Light' )  => 'light',
				),
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Number', 'js_composer' ),
				'param_name'  => 'number'
			),
			array(
				'type'        => 'checkbox',
				'heading'     => __( 'Seperator Item', 'js_composer' ),
				'param_name'  => 'seperator_item'
			),
			array(
				'type'        => 'checkbox',
				'heading'     => __( 'Procent Item', 'js_composer' ),
				'param_name'  => 'procent'
			),
		),
	)
);


class WPBakeryShortCode_antica_process_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {
		global $antica_process_items;
		$antica_process_items[] = array( 'atts' => $atts, 'content' => $content);
		return;
	}
}
		