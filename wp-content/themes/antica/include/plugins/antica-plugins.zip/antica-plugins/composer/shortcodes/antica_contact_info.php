<?php 
/*
 * Contact Shortcode
 * Author: QodeArena
 * Author URI: http://qodearena.com/
 * Version: 1.0.0 
 */

vc_map( 
	array(
		'name'                    => __( 'Contact Info', 'js_composer' ),
		'base'                    => 'antica_contact',
		'content_element'         => true,
		'show_settings_on_create' => true,
		'params' => array(
			array(
				'type' 		  => 'textfield',
				'heading' 	  => __( 'Title', 'js_composer' ),
				'param_name'  => 'title'
			),
			array(
				'type'       => 'param_group',
				'heading'    => __( 'Items', 'js_composer' ),
				'param_name' => 'items',
				'params'     => array(
					array(
						'type' 		  => 'textarea',
						'heading' 	  => __( 'Text', 'js_composer' ),
						'param_name'  => 'text'
					),
					array(
						'type' 		  => 'textfield',
						'heading' 	  => __( 'URL', 'js_composer' ),
						'param_name'  => 'url',
						'value' 	  => ''
					),
				),
				'callbacks' => array(
					'after_add' => 'vcChartParamAfterAddCallback'
				)
			),
			array(
				'heading' 	  => __( 'Color Style', 'js_composer' ),
				'type' 		  => 'dropdown',
				'param_name'  => 'color_style',
				'value' 	  => array(
					__( 'Light', 'js_composer' ) => 'light',
					__( 'Dark', 'js_composer' )  => 'dark',
				)
			),
			array(
				'heading' 	  => __( 'Align', 'js_composer' ),
				'type' 		  => 'dropdown',
				'param_name'  => 'block_align',
				'value' 	  => array(
					__( 'Left', 'js_composer' ) => 'left',
					__( 'Center', 'js_composer' ) => 'center',
					__( 'Right', 'js_composer' ) => 'right'
				)
			),
			array(
				'type' 		  => 'textfield',
				'heading' 	  => __( 'Extra class name', 'js_composer' ),
				'param_name'  => 'el_class',
				'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
				'value' 	  => ''
			),
			array(
				'type' 		  => 'css_editor',
				'heading' 	  => __( 'CSS box', 'js_composer' ),
				'param_name'  => 'css',
				'group' 	  => __( 'Design options', 'js_composer' )
			)
		) //end params
	)
);

class WPBakeryShortCode_antica_contact extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'title' 	    => '',
			'block_align'   => 'left',
			'items' 	    => '',
			'color_style' 	=> 'light',
			'el_class' 	    => '',
			'css' 		    => ''
		), $atts ) );

		$output 	= '';
		$css_styles = '';
		$items 	  	= json_decode( urldecode( $items ), true );
		$class  	= ( ! empty( $el_class ) ) ? $el_class : '';
		$class 	   .= vc_shortcode_custom_css_class( $css, ' ' );
		$class 	   .= ' text-' . $block_align;

		// Color Style
		$color_style = ( isset( $color_style ) && $color_style == 'light' ) ? 'light' : $color_style;

		if( ! empty( $items ) ) {
			$output .= '<div class="contact-info ' . $class . ' ' . $color_style . '">';
			if( ! empty( $title ) ) {
				$output .= '<h5 class="contact-info-title">' . $title . '</h5>';
			}
			$output .= '<ul>';
			foreach ( $items as $item ) {
				if( ! empty( $item['text'] ) ) {
					if( ! empty( $item['url'] ) ) {
						$output .= '<li><a href="' . esc_url( $item['url'] ) . '">' . $item['text'] . '</a></li>';
					} else {
						$output .= '<li>' . $item['text'] . '</li>';
					}
				}
			}
			$output .= '</ul>';
			
			$output .= '</div>';
			
			return $output;
		}
	}
}