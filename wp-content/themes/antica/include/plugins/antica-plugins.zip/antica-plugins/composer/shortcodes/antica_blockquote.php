<?php 
/*
 * Blockquote Shortcode
 * Author: QodeArena
 * Author URI: https://themeforest.net/user/qodearena
 * Version: 1.0.0 
 */

vc_map(
	array(
		'name'        => __( 'Blockquote Block', 'js_composer' ),
		'base'        => 'antica_blockquote',
		'params'      => array(
			array(
				'type'        => 'textarea_html',
				'heading'     => __( 'Item text', 'js_composer' ),
				'param_name'  => 'content',
				'value'       => ''
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Author Blockquotes', 'js_composer' ),
				'admin_label' => true,
				'param_name'  => 'author'
			),
			
			/* CSS editor */
			array(
				'type' 		  => 'css_editor',
				'heading' 	  => __( 'CSS box', 'js_composer' ),
				'param_name'  => 'css',
				'group' 	  => __( 'Design options', 'js_composer' )
			)
		)
	)
);

class WPBakeryShortCode_antica_blockquote extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'author'			=> '',
			'el_class' 			=> '',
			'title_font_size' 	=> '',
			'title_color' 		=> '',
			'title_font_family' => 'default',
			'title_font' 	    => '',
			'css' 			    => ''
		), $atts ) );

		$google_fonts = new Vc_Google_Fonts;

		$class  = ( ! empty( $el_class ) ) ? $el_class : '';
		$class .= vc_shortcode_custom_css_class( $css, ' ' );

		$output = '';

		$title_style 	= '';

		/* Get styles from options */
		$styles = array('title');

		foreach ( $styles as $item ) {

			if( ! empty( ${$item."_font_size"} ) ) {
				${$item."_style"} = ( is_numeric( ${$item."_font_size"} ) ) ? 'font-size: ' . ${$item."_font_size"} . 'px;' : 'font-size: ' . ${$item."_font_size"} . ';'; 
			}
			${$item."_style"} .= ( ! empty( ${$item."_color"} ) ) ? 'color: ' . ${$item."_color"} . ';' : '';

			$title_style .= ( ! empty( $title_color ) ) ? 'color: ' . $title_color . ';' : '';

			if( ${$item."_font_family"} == 'custom' ) {
				${$item."_font"} = $google_fonts->_vc_google_fonts_parse_attributes( $atts, ${$item."_font"} );

				$subsets  = '';
				$settings = get_option( 'wpb_js_google_fonts_subsets' );
				if ( is_array( $settings ) && ! empty( $settings ) ) {
					$subsets = '&subset=' . implode( ',', $settings );
				}

				wp_enqueue_style( 'vc_google_fonts_' . vc_build_safe_css_class( ${$item."_font"}['values']['font_family'] ), '//fonts.googleapis.com/css?family=' . ${$item."_font"}['values']['font_family'] . $subsets );
				
				${$item."_font"} = explode( ':', ${$item."_font"}['values']['font_family'] );
				
				${$item."_style"} .= 'font-family: ' . ${$item."_font"}[0] . ';';
			}

			${$item."_style"} = ( ! empty( ${$item."_style"} ) ) ? 'style="' . ${$item."_style"} . '"' : '';

		}

        // Author blockquote
        $author = ( ! empty( $author ) ) ? $author : '';

        // Content blockquote
        $content = ( ! empty( $content ) ) ? $content : '';

        $output .='<div class="blockquote-block ' . $class . '">';
            $output .='<p>' . $content . '</p>';
            $output .='<span class="author">' . $author . '</span>';
        $output .='</div>';

		return $output;
	}
}