<?php 
/*
 * Content Slider Shortcode
 * Author: QodeArena
 * Author URI: http://qodearena.com/
 * Version: 1.0.0 
 */

vc_map( 
	array(
		'name'                    => __( 'Content slider', 'js_composer' ),
		'base'                    => 'antica_content_slider',
		'as_parent' 		      => array('only' => 'antica_content_slider_item'),
		'content_element'         => true,
		'show_settings_on_create' => false,
		'js_view'                 => 'VcColumnView',
		'params'          		  => array(
			array(
				'heading' 	  => __( 'Style Slider', 'js_composer' ),
				'type' 		  => 'dropdown',
				'param_name'  => 'style_slider',
				'value' 	  => array(
					__( 'Default', 'js_composer' ) => 'default',
					__( 'Modern', 'js_composer' )  => 'modern'
				)
			),
			array(
				'heading' 	  => __( 'Custom slider height', 'js_composer' ),
				'type' 		  => 'dropdown',
				'param_name'  => 'height',
				'value' 	  => array(
					__( 'Default', 'js_composer' ) => 'default',
					__( 'Custom', 'js_composer' )  => 'custom_height'
				)
			),
			array(
				'type'        => 'checkbox',
				'heading'     => __( 'Seperator Slider', 'js_composer' ),
				'param_name'  => 'seperator_slider'
			),
			array(
				'type' 		  => 'textfield',
				'heading' 	  => __( 'Default height', 'js_composer' ),
				'param_name'  => 'custom_height_size',
				'value' 	  => '',
				'dependency'  => array( 'element' => 'height', 'value' => 'custom_height' )
			),
			array(
				'type' 		  => 'textfield',
				'heading' 	  => __( 'Extra class name', 'js_composer' ),
				'param_name'  => 'el_class',
				'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
				'value' 	  => ''
			),
			array(
				'type' 		  => 'css_editor',
				'heading' 	  => __( 'CSS box', 'js_composer' ),
				'param_name'  => 'css',
				'group' 	  => __( 'Design options', 'js_composer' )
			)
		) //end params
	)
);

class WPBakeryShortCode_antica_content_slider extends WPBakeryShortCodesContainer {
	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'style_slider'       => 'default',
			'height'             => 'default',
			'seperator_slider'   => false,
			'custom_height_size' => '',
			'css'	             => '',
			'el_class'           => ''
		), $atts ) );

		$class  = ( ! empty( $el_class ) ) ? $el_class : '';
		$class .= vc_shortcode_custom_css_class( $css, ' ' );
		$output = '';

		global $antica_content_slider_items;
		$antica_content_slider_items = '';

		do_shortcode( $content );

		$height_value = '';
		if( $height == 'custom_height' ) {
	    	$height_value .= ( ! empty( $custom_height_size ) && is_numeric( $custom_height_size ) ) ? $custom_height_size . 'px' :  '500px';
		}
		else {
			$height_value .= '100vh';
		}	
	    $height_slider = 'style="height: ' . $height_value . ';"';

	    // Seperator Slider 
		$seperator_slider = ( isset( $seperator_slider ) && $seperator_slider == 'true' ) ? 'seperator' : '';
		
		$counter = 0;

		if( ! empty( $antica_content_slider_items ) && count( $antica_content_slider_items ) > 0 ) { 

				$output .= '<div class="slider-content ' . $style_slider . ' '. $seperator_slider . '">';
				    $output .= '<div class="swiper-container ' . $class . '" data-autoplay="3000" data-touch="1" data-mouse="0" data-slides-per-view="1" data-loop="0" data-speed="1000" id="slider-' . $counter . '">';
		                $output .= '<div class="swiper-wrapper">';

							foreach ( $antica_content_slider_items as $key => $item ) {
								$value = (object) $item['atts'];

								$image = ( ! empty( $value->image ) && is_numeric( $value->image ) ) ? wp_get_attachment_url( $value->image ) : '';
								$link = ( ! empty( $value->button ) ) ? vc_build_link( $value->button ) : '';
								$link_target = ( ! empty( $link['target'] ) ) ? 'target="' . $link['target'] . '"' : ''; 

								$button = ( ! empty( $link ) ) ? '<a href="' . esc_url( $link['url'] ) . '" class="btn-slider" ' . $link_target . '>' . esc_html( $link['title'] ) . '</a>' : '';

						        // $output .= '<div class="slide" data-anchor="slide' . $counter . '"  id="slides' . $counter . '">';
						        // 	$output .= '<img src="' . $image . '" class="hidden img-post" alt="">';
						        //     $output .= '<div class="page_first_bg"><span>ntica</span></div>';
						        //     $output .= '<div class="intro">';
						        //         $output .= '<div class="container-fluid">';
						        //             $output .= '<div class="row">';
						        //                 $output .= '<div class="col-md-8 col-md-offset-2">';
						        //                     $output .= '<div class="quote">';
						        //                         $output .= ( ! empty( $value->title ) ) ? '<h2>' . $value->title . '</h2>' : '';
						        //                         $output .= '<i>' . $item['content'] . '</i>';
						        //                         $output .= $button;
						        //                     $output .= '</div>';
						        //                 $output .= '</div>';
						        //             $output .= '</div>';
						        //         $output .= '</div>';
						        //     $output .= '</div>';
						        // $output .= '</div>';

		                        $output .= '<div class="swiper-slide">';
									if( $style_slider == 'default' ) {
			                        	$output .= '<div class="bg-slide" ' . $height_slider . '>';
			                            	$output .= '<img src="' . $image . '" class="hidden img-post" alt="">';
			                        	$output .= '</div>';
									} else {
										$output .= '<div class="swiper-slide-container">';
											$output .= ( ! empty( $value->title ) ) ? '<p>' . $value->title . '</p>' : '';
											$output .= $button;
										$output .= '</div>';
									}
								$output .= '</div>';

						        $counter++;
						    }    
					    $output .= '</div>';
		                $output .= '<div class="pagination"></div>';
				    $output .= '</div>';
			    $output .= '</div>';

		}
		return $output;
	}
}

vc_map( 
	array(
		'name'            => 'Item',
		'base'            => 'antica_content_slider_item',
		'as_child' 		  => array('only' => 'antica_content_slider'),
		'content_element' => true,
		'params'          => array(
			array(
				'type'        => 'textarea',
				'heading'     => __( 'Title', 'js_composer' ),
				'param_name'  => 'title',
				'value'       => ''
			),
			array(
				'type'     	  => 'textarea',
				'heading'     => __( 'Subtitle', 'js_composer' ),
				'param_name'  => 'content',
				'holder'      => 'div',
				'value'    	  => ''
			),
			array(
				'type'        => 'attach_image',
				'heading'     => __( 'Image', 'js_composer' ),
				'param_name'  => 'image'
			),
			array(
				'type' 		  => 'vc_link',
				'heading' 	  => __( 'Button', 'js_composer' ),
				'param_name'  => 'button'
			),
		),
	)
);


class WPBakeryShortCode_antica_content_slider_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {
		global $antica_content_slider_items;
		$antica_content_slider_items[] = array( 'atts' => $atts, 'content' => $content);
		return;
	}
}