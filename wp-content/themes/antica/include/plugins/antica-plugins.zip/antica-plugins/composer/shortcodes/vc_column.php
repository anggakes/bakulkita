<?php
/*
 * VC Row Shortcode
 * Author: QodeArena
 * Author URI: http://qodearena.com/
 * Version: 1.0.0 
 * Add option for row paddings
 */

$responsive_classes = array(
    array(
        'type'        => 'dropdown',
        'heading'     => __( 'Desctop margin top', 'js_composer' ),
        'param_name'  => 'desctop_mt',
        'value'       => array(
            'Default'  => 'none',
            '5px'      => 'mt-md-5',
            '10px'     => 'mt-md-10',
            '15px'     => 'mt-md-15',
            '20px'     => 'mt-md-20',
            '25px'     => 'mt-md-25',
            '30px'     => 'mt-md-30',
            '35px'     => 'mt-md-35',
            '40px'     => 'mt-md-40',
            '45px'     => 'mt-md-45',
            '50px'     => 'mt-md-50',
            '90px'     => 'mt-md-90',
        ),
        'group'       => 'Responsive Margins'
    ),
    array(
        'type'        => 'dropdown',
        'heading'     => __( 'Desctop margin bottom', 'js_composer' ),
        'param_name'  => 'desctop_mb',
        'value'       => array(
            'Default'  => 'none',
            '5px'      => 'mb-md-5',
            '10px'     => 'mb-md-10',
            '15px'     => 'mb-md-15',
            '20px'     => 'mb-md-20',
            '25px'     => 'mb-md-25',
            '30px'     => 'mb-md-30',
            '35px'     => 'mb-md-35',
            '40px'     => 'mb-md-40',
            '45px'     => 'mb-md-45',
            '50px'     => 'mb-md-50',
        ),
        'group'       => 'Responsive Margins',
    ),
    array(
        'type'        => 'dropdown',
        'heading'     => __( 'Tablets margin top', 'js_composer' ),
        'param_name'  => 'tablets_mt',
        'value'       => array(
            'Default'  => 'none',
            '5px'      => 'mt-sm-5',
            '10px'     => 'mt-sm-10',
            '15px'     => 'mt-sm-15',
            '20px'     => 'mt-sm-20',
            '25px'     => 'mt-sm-25',
            '30px'     => 'mt-sm-30',
            '35px'     => 'mt-sm-35',
            '40px'     => 'mt-sm-40',
            '45px'     => 'mt-sm-45',
            '50px'     => 'mt-sm-50',
        ),
        'group'       => 'Responsive Margins'
    ),
    array(
        'type'        => 'dropdown',
        'heading'     => __( 'Tablets margin bottom', 'js_composer' ),
        'param_name'  => 'tablets_mb',
        'value'       => array(
            'Default'  => 'none',
            '5px'      => 'mb-sm-5',
            '10px'     => 'mb-sm-10',
            '15px'     => 'mb-sm-15',
            '20px'     => 'mb-sm-20',
            '25px'     => 'mb-sm-25',
            '30px'     => 'mb-sm-30',
            '35px'     => 'mb-sm-35',
            '40px'     => 'mb-sm-40',
            '45px'     => 'mb-sm-45',
            '50px'     => 'mb-sm-50',
        ),
        'group'       => 'Responsive Margins'
    ),
    array(
        'type'        => 'dropdown',
        'heading'     => __( 'Mobile margin top', 'js_composer' ),
        'param_name'  => 'mobile_mt',
        'value'       => array(
            'Default'  => 'none',
            '5px'      => 'mt-xs-5',
            '10px'     => 'mt-xs-10',
            '15px'     => 'mt-xs-15',
            '20px'     => 'mt-xs-20',
            '25px'     => 'mt-xs-25',
            '30px'     => 'mt-xs-30',
            '35px'     => 'mt-xs-35',
            '40px'     => 'mt-xs-40',
            '45px'     => 'mt-xs-45',
            '50px'     => 'mt-xs-50',
        ),
        'group'       => 'Responsive Margins'
    ),
    array(
        'type'        => 'dropdown',
        'heading'     => __( 'Mobile margin bottom', 'js_composer' ),
        'param_name'  => 'mobile_mb',
        'value'       => array(
            'Default'  => 'none',
            '5px'      => 'mb-xs-5',
            '10px'     => 'mb-xs-10',
            '15px'     => 'mb-xs-15',
            '20px'     => 'mb-xs-20',
            '25px'     => 'mb-xs-25',
            '30px'     => 'mb-xs-30',
            '35px'     => 'mb-xs-35',
            '40px'     => 'mb-xs-40',
            '45px'     => 'mb-xs-45',
            '50px'     => 'mb-xs-50',
        ),
        'group'       => 'Responsive Margins'
    ),
    array(
        'type'        => 'dropdown',
        'heading'     => __( 'Desctop padding left', 'js_composer' ),
        'param_name'  => 'desctop_pl',
        'value'       => array(
            'Default'  => 'none',
            '5px'      => 'pl-md-5',
            '10px'     => 'pl-md-10',
            '15px'     => 'pl-md-15',
            '20px'     => 'pl-md-20',
            '25px'     => 'pl-md-25',
            '30px'     => 'pl-md-30',
            '35px'     => 'pl-md-35',
            '40px'     => 'pl-md-40',
            '45px'     => 'pl-md-45',
            '60px'     => 'pl-md-60',
        ),
        'group'       => 'Responsive Paddings'
    ),
    array(
        'type'        => 'dropdown',
        'heading'     => __( 'Desctop padding right', 'js_composer' ),
        'param_name'  => 'desctop_pr',
        'value'       => array(
            'Default'  => 'none',
            '5px'      => 'pr-md-5',
            '10px'     => 'pr-md-10',
            '15px'     => 'pr-md-15',
            '20px'     => 'pr-md-20',
            '25px'     => 'pr-md-25',
            '30px'     => 'pr-md-30',
            '35px'     => 'pr-md-35',
            '40px'     => 'pr-md-40',
            '45px'     => 'pr-md-45',
            '60px'     => 'pr-md-60',
        ),
        'group'       => 'Responsive Paddings'
    ),
    array(
        'type'        => 'dropdown',
        'heading'     => __( 'Desctop padding top', 'js_composer' ),
        'param_name'  => 'desctop_pt',
        'value'       => array(
            'Default'  => 'none',
            '5px'      => 'pt-md-5',
            '10px'     => 'pt-md-10',
            '15px'     => 'pt-md-15',
            '20px'     => 'pt-md-20',
            '25px'     => 'pt-md-25',
            '30px'     => 'pt-md-30',
            '35px'     => 'pt-md-35',
            '40px'     => 'pt-md-40',
            '45px'     => 'pt-md-45',
            '75px'     => 'pt-md-75',
            '100px'    => 'pt-md-100',
            '135px'    => 'pt-md-135',
            '140px'    => 'pt-md-140'
        ),
        'group'       => 'Responsive Paddings'
    ),
    array(
        'type'        => 'dropdown',
        'heading'     => __( 'Desctop padding bottom', 'js_composer' ),
        'param_name'  => 'desctop_pb',
        'value'       => array(
            'Default'  => 'none',
            '5px'      => 'pb-md-5',
            '10px'     => 'pb-md-10',
            '15px'     => 'pb-md-15',
            '20px'     => 'pb-md-20',
            '25px'     => 'pb-md-25',
            '30px'     => 'pb-md-30',
            '35px'     => 'pb-md-35',
            '40px'     => 'pb-md-40',
            '45px'     => 'pb-md-45',
            '50px'     => 'pb-md-50',
            '75px'     => 'pb-md-75',
            '100px'    => 'pb-md-100',
            '135px'    => 'pb-md-135',
            '140px'    => 'pb-md-140'
        ),
        'group'       => 'Responsive Paddings',
    ),
    array(
        'type'        => 'dropdown',
        'heading'     => __( 'Tablets padding top', 'js_composer' ),
        'param_name'  => 'tablets_pt',
        'value'       => array(
            'Default'  => 'none',
            '5px'      => 'pt-sm-5',
            '10px'     => 'pt-sm-10',
            '15px'     => 'pt-sm-15',
            '20px'     => 'pt-sm-20',
            '25px'     => 'pt-sm-25',
            '30px'     => 'pt-sm-30',
            '35px'     => 'pt-sm-35',
            '40px'     => 'pt-sm-40',
            '45px'     => 'pt-sm-45',
            '50px'     => 'pt-sm-50',
            '75px'     => 'pt-sm-75',
            '100px'    => 'pt-sm-100',
            '135px'    => 'pt-sm-135',
            '140px'    => 'pt-sm-140'
        ),
        'group'       => 'Responsive Paddings'
    ),
    array(
        'type'        => 'dropdown',
        'heading'     => __( 'Tablets padding bottom', 'js_composer' ),
        'param_name'  => 'tablets_pb',
        'value'       => array(
            'Default'  => 'none',
            '5px'      => 'pb-sm-5',
            '10px'     => 'pb-sm-10',
            '15px'     => 'pb-sm-15',
            '20px'     => 'pb-sm-20',
            '25px'     => 'pb-sm-25',
            '30px'     => 'pb-sm-30',
            '35px'     => 'pb-sm-35',
            '40px'     => 'pb-sm-40',
            '45px'     => 'pb-sm-45',
            '50px'     => 'pb-sm-50',
            '75px'     => 'pb-sm-75',
            '100px'    => 'pb-sm-100',
            '135px'    => 'pb-sm-135',
            '140px'    => 'pb-sm-140'
        ),
        'group'       => 'Responsive Paddings'
    ),
    array(
        'type'        => 'dropdown',
        'heading'     => __( 'Mobile padding top', 'js_composer' ),
        'param_name'  => 'mobile_pt',
        'value'       => array(
            'Default'  => 'none',
            '5px'      => 'pt-xs-5',
            '10px'     => 'pt-xs-10',
            '15px'     => 'pt-xs-15',
            '20px'     => 'pt-xs-20',
            '25px'     => 'pt-xs-25',
            '30px'     => 'pt-xs-30',
            '35px'     => 'pt-xs-35',
            '40px'     => 'pt-xs-40',
            '45px'     => 'pt-xs-45',
            '50px'     => 'pt-xs-50',
            '75px'     => 'pt-xs-75',
            '100px'    => 'pt-xs-100',
            '135px'    => 'pt-xs-135',
            '140px'    => 'pt-xs-140'
        ),
        'group'       => 'Responsive Paddings'
    ),
    array(
        'type'        => 'dropdown',
        'heading'     => __( 'Mobile padding bottom', 'js_composer' ),
        'param_name'  => 'mobile_pb',
        'value'       => array(
            'Default'  => 'none',
            '5px'      => 'pb-xs-5',
            '10px'     => 'pb-xs-10',
            '15px'     => 'pb-xs-15',
            '20px'     => 'pb-xs-20',
            '25px'     => 'pb-xs-25',
            '30px'     => 'pb-xs-30',
            '35px'     => 'pb-xs-35',
            '40px'     => 'pb-xs-40',
            '45px'     => 'pb-xs-45',
            '50px'     => 'pb-xs-50',
            '75px'     => 'pb-xs-75',
            '100px'    => 'pb-xs-100',
            '135px'    => 'pb-xs-135',
            '140px'    => 'pb-xs-140'
        ),
        'group'       => 'Responsive Paddings'
    )
);

vc_add_params( 'vc_column', $responsive_classes );
