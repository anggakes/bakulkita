<?php 
/*
 * Contact form Shortcode
 * Author: QodeArena
 * Author URI: http://qodearena.com/
 * Version: 1.0.0 
 */

vc_map(
  	array(
	    'name'        => __( 'Contact form', 'js_composer' ),
	    'base'        => 'antica_form',
	    'params'      => array(
	      	array(
				'heading' 	  => __( 'Select form', 'js_composer' ),
				'type' 		  => 'dropdown',
				'param_name'  => 'form',
				'value' 	  => antica_get_cf7_forms()
			),
			array(
				'heading' 	  => __( 'Color Style', 'js_composer' ),
				'type' 		  => 'dropdown',
				'param_name'  => 'color_style',
				'value' 	  => array(
					__( 'Light', 'js_composer' ) => 'light',
					__( 'Dark', 'js_composer' )  => 'dark',
				)
			),
			array(
				'type' 		  => 'textfield',
				'heading' 	  => __( 'Extra class name', 'js_composer' ),
				'param_name'  => 'el_class',
				'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
				'value' 	  => ''
			),
			array(
				'type' 		  => 'css_editor',
				'heading' 	  => __( 'CSS box', 'js_composer' ),
				'param_name'  => 'css',
				'group' 	  => __( 'Design options', 'js_composer' )
			)
	    )
  	)
);

class WPBakeryShortCode_antica_form extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
		    'form' 				=> 'none',
		    'color_style' 	    => 'light',
		    'el_class' 			=> '',
		    'css' 				=> ''
		), $atts ) );

		if( $form != 'none' ) {
			$class  	   = ( ! empty( $el_class ) ) ? $el_class : '';
			$class 		  .= vc_shortcode_custom_css_class( $css, ' ' );

			// Color Style
			$color_style = ( isset( $color_style ) && $color_style == 'light' ) ? 'light' : $color_style;

			$output	= '<div class="antica-contact-form ' . $class . ' ' . $color_style . '">';
			$output	.= do_shortcode( '[contact-form-7 id="' . $form . '"]' );;
			$output	.= '</div>';

			return  $output;
		}
	}
}