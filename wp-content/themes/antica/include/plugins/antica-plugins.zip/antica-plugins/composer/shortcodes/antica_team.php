<?php 
/*
 * Team Shortcode
 * Author: QodeArena
 * Author URI: https://themeforest.net/user/qodearena
 * Version: 1.0.0 
 */

vc_map( 
	array(
		'name'                    => __( 'Team', 'js_composer' ),
		'base'                    => 'antica_team',
		'as_parent' 		      => array('only' => 'antica_team_item'),
		'content_element'         => true,
		'show_settings_on_create' => false,
		'js_view'                 => 'VcColumnView',
		'params'          		  => array(
			array(
				'type'        => 'dropdown',
				'heading'     => __( 'Style Team', 'js_composer' ),
				'param_name'  => 'style',
				'value'       => array(
					'Classic' => 'classic',
					'Modern'  => 'modern',
				)
			),
			array(
				'type' 		  => 'textfield',
				'heading' 	  => __( 'Extra class name', 'js_composer' ),
				'param_name'  => 'el_class',
				'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
				'value' 	  => ''
			),
			array(
				'type' 		  => 'css_editor',
				'heading' 	  => __( 'CSS box', 'js_composer' ),
				'param_name'  => 'css',
				'group' 	  => __( 'Design options', 'js_composer' )
			)
		) //end params
	)
);

class WPBakeryShortCode_antica_team extends WPBakeryShortCodesContainer {
	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'style'	   		   => 'classic',
			'css'	   		   => '',
			'el_class' 		   => ''
		), $atts ) );

		$class  = ( ! empty( $el_class ) ) ? $el_class : '';
		$class .= vc_shortcode_custom_css_class( $css, ' ' );
		$output = '';

		global $antica_team_items;
		$antica_team_items = '';

		do_shortcode( $content );

		if( ! empty( $antica_team_items ) && count( $antica_team_items ) > 0 ) {

			$output = '';

			if( $style == 'classic' ) {
				$output .= '<div class="team_page ' . $style . ' ' . $class . '">';
			} else {
				$output .= '<div class="swiper-container team-slider" data-autoplay="5000" data-loop="1" data-speed="1000" data-slides-per-view="responsive" data-add-slides="1" data-xs-slides="1" data-sm-slides="1" data-md-slides="1" data-lg-slides="1">';
					$output .= '<div class="swiper-wrapper">';
			}	
			
			foreach ( $antica_team_items as $key => $item ) {
				$value = (object) $item['atts'];

				// Image
				$image 	= ( ! empty( $value->image ) && is_numeric( $value->image ) ) ? wp_get_attachment_url( $value->image ) : '';

				$head  = ( ! empty( $value->name ) ) ? '<h2>' . $value->name . '</h2>' : '';
				$head .= ( ! empty( $value->position ) ) ? '<span>' . $value->position . '</span>' : '';
				
				// Name 	
				$name = ( ! empty( $value->name ) ) ? $value->name : '';

				$social_items = '';
				if( ! empty( $value->social ) ) {
					$social_items .= '<nav>';
						$social_items .= '<ul>';

						$items = json_decode( urldecode( $value->social ), true );
						foreach ( $items as $item ) {
							$social_items .= '<li><a href="' . esc_url( $item['url'] ) . '" class="' . esc_attr( $item['icon'] ) . '"></a></li>';
						}

						$social_items .= '</ul>';
					$social_items .= '</nav>';
				}

				if( $style == 'classic' ) {
					$output .= '<div class="team_item">';
		                $output .= '<div class="team_item_show"><img src="' . $image . '" alt="' . $name . '" title="' . $name . '"></div>';
		                $output .= '<div class="team_item_hide">';
		                    $output .= '<div class="team_item_hide_body">';
		                        $output .= $head;
		                        $output .= $social_items;
		                    $output .= '</div>';
		                $output .= '</div>';
		            $output .= '</div>';
				} else {
					$output .= '<div class="team_body_slide swiper-slide">';

						$team_items	= json_decode( urldecode( $value->team_items ), true );

						if( ! empty( $team_items ) ) {
							foreach ($team_items as $item) {

								// Image
								$image 	= ( ! empty( $item['image'] ) && is_numeric( $item['image'] ) ) ? wp_get_attachment_url( $item['image'] ) : '';

								$head  = ( ! empty( $item['name'] ) ) ? '<h2>' . $item['name'] . '</h2>' : '';
								$head .= ( ! empty( $item['position'] ) ) ? '<span>' . $item['position'] . '</span>' : '';
								
								// Name 	
								$name = ( ! empty( $item['name'] ) ) ? $item['name'] : '';

								$social_items = '';
								if( ! empty( $item['social'] ) ) {
									$social_items .= '<nav>';
										$social_items .= '<ul>';

										$items = json_decode( urldecode( $item['social'] ), true );
										foreach ( $items as $item ) {
											$social_items .= '<li><a href="' . esc_url( $item['url'] ) . '" class="' . esc_attr( $item['icon'] ) . '"></a></li>';
										}

										$social_items .= '</ul>';
									$social_items .= '</nav>';
								}

								$output .= '<div class="team_item">';
					                $output .= '<div class="team_item_show"><img src="' . $image . '" alt="' . $name . '" title="' . $name . '"></div>';
					                $output .= '<div class="team_item_hide">';
					                    $output .= '<div class="team_item_hide_body">';
					                        $output .= $head;
					                        $output .= $social_items;
					                    $output .= '</div>';
					                $output .= '</div>';
					            $output .= '</div>';
							}
						}
						
		            $output .= '</div>';
				}

			}	

			if( $style == 'classic' ) {
				$output .= '</div>';
			} else {
				$output .= '</div>';
				$output .= '<div class="pagination"></div>';
					$output .= '</div>';
			}	
		}

		return $output;
	}
}

vc_map( 
	array(
		'name'            => 'Item',
		'base'            => 'antica_team_item',
		'as_child' 		  => array('only' => 'antica_team'),
		'content_element' => true,
		'params'          => array(
			array(
				'heading' 	  => __( 'Style', 'js_composer' ),
				'type' 		  => 'dropdown',
				'param_name'  => 'style',
				'value' 	  => array(
					__( 'Classic', 'js_composer' ) => 'classic',
					__( 'Modern', 'js_composer' )  => 'modern'
				),
				'description' => 'When you select style for one unique item, it need to refer to parent style.',
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Name', 'js_composer' ),
				'admin_label' => true,
				'param_name'  => 'name',
				'dependency' => array( 'element' => 'style', 'value' => 'classic' ),
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Position', 'js_composer' ),
				'admin_label' => true,
				'param_name'  => 'position',
				'dependency' => array( 'element' => 'style', 'value' => 'classic' ),
			),
			array(
				'type'        => 'attach_image',
				'heading'     => __( 'Photo', 'js_composer' ),
				'param_name'  => 'image',
				'dependency' => array( 'element' => 'style', 'value' => 'classic' ),
			),
			array(
				'type'       => 'param_group',
				'heading'    => __( 'Social', 'js_composer' ),
				'param_name' => 'social',
				'params'     => array(
					array(
						'type'        => 'iconpicker',
						'heading'     => __( 'Social icon', 'js_composer' ),
						'param_name'  => 'icon',
						'description' => __( 'Select icon from library.', 'js_composer' )
					),
					array(
						'type'        => 'textfield',
						'heading'     => __( 'Socail URL', 'js_composer' ),
						'param_name'  => 'url',
						'value'       => ''
					)
				),
				'dependency' => array( 'element' => 'style', 'value' => 'classic' ),
				'callbacks' => array(
					'after_add' => 'vcChartParamAfterAddCallback'
				)
			),
			array(
				'type'       => 'param_group',
				'heading'    => __( 'Item team', 'js_composer' ),
				'param_name' => 'team_items',
				'params'     => array(
					array(
						'type'        => 'textfield',
						'heading'     => __( 'Name', 'js_composer' ),
						'admin_label' => true,
						'param_name'  => 'name'
					),
					array(
						'type'        => 'textfield',
						'heading'     => __( 'Position', 'js_composer' ),
						'admin_label' => true,
						'param_name'  => 'position'
					),
					array(
						'type'        => 'attach_image',
						'heading'     => __( 'Photo', 'js_composer' ),
						'param_name'  => 'image'
					),
					array(
						'type'       => 'param_group',
						'heading'    => __( 'Social', 'js_composer' ),
						'param_name' => 'social',
						'params'     => array(
							array(
								'type'        => 'iconpicker',
								'heading'     => __( 'Social icon', 'js_composer' ),
								'param_name'  => 'icon',
								'description' => __( 'Select icon from library.', 'js_composer' )
							),
							array(
								'type'        => 'textfield',
								'heading'     => __( 'Socail URL', 'js_composer' ),
								'param_name'  => 'url',
								'value'       => ''
							)
						),
						'dependency' => array( 'element' => 'style', 'value' => 'classic' ),
						'callbacks' => array(
							'after_add' => 'vcChartParamAfterAddCallback'
						)
					),
				),
				'dependency' => array( 'element' => 'style', 'value' => 'modern' ),
				'callbacks' => array(
					'after_add' => 'vcChartParamAfterAddCallback'
				)
			),
		),
	)
);


class WPBakeryShortCode_antica_team_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {
		global $antica_team_items;
		$antica_team_items[] = array( 'atts' => $atts, 'content' => $content);
		return;
	}
}
