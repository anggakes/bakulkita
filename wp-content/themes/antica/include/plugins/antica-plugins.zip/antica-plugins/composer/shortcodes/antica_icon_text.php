<?php 
/*
 * Icon Text Shortcode
 * Author: QodeArena
 * Author URI: http://qodearena.com/
 * Version: 1.0.0 
 */

vc_map(
	array(
		'name'        => __( 'Icon Text', 'js_composer' ),
		'base'        => 'antica_icon_text',
		'params'      => array(
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Title', 'js_composer' ),
				'admin_label' => true,
				'param_name'  => 'title'
			),
			array(
				'heading' 	  => __( 'Icon style', 'js_composer' ),
				'type' 		  => 'dropdown',
				'param_name'  => 'icon_type',
				'value' 	  => array(
					__( 'Font awesome', 'js_composer' ) => 'faw',
					__( 'Flaticon', 'js_composer' ) 	=> 'ion'
				),
			),
			array(
				'type' 		  => 'iconpicker',
				'heading' 	  => __( 'Icon', 'js_composer' ),
				'param_name'  => 'icon_ion',
				'value' 	  => 'icon-adjustments',
				'settings' 	  => array(
					'emptyIcon'    => false,
					'type' 		   => 'flaticon',
					'source' 	   => antica_ion_icons(),
					'iconsPerPage' => 4000,
				),
				'dependency'  => array( 'element' => 'icon_type', 'value'   => 'ion' ),
				'description' => __( 'Select icon from library.', 'js_composer' ),
			),
			array(
				'heading'     => __( 'Icon', 'js_composer' ),
				'type'        => 'iconpicker',
				'param_name'  => 'icon',
				'description' => __( 'Select icon from library.', 'js_composer' ),
				'dependency'  => array( 'element' => 'icon_type', 'value' => 'faw' )
			),
			array(
				'type' 		  => 'textarea',
				'heading'     => __( 'Content', 'js_composer' ),
				'param_name'  => 'text',
				'value' 	  => ''
			),
			array(
				'type'        => 'checkbox',
				'heading'     => __( 'Seperator Item', 'js_composer' ),
				'param_name'  => 'seperator_item'
			),
			array(
				'heading' 	  => __( 'Style Color', 'js_composer' ),
				'type' 		  => 'dropdown',
				'param_name'  => 'style_color',
				'value' 	  => array(
					__( 'Dark', 'js_composer' )   => 'dark',
					__( 'Light', 'js_composer' )  => 'light',
				),
			),
			array(
				'type' 		  => 'textfield',
				'heading' 	  => __( 'Extra class name', 'js_composer' ),
				'param_name'  => 'el_class',
				'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
				'value' 	  => ''
			),
			/* Style tab */
			array(
				'heading' 	  => __( 'Block align', 'js_composer' ),
				'type' 		  => 'dropdown',
				'param_name'  => 'align',
				'value' 	  => array(
					__( 'Left', 'js_composer' )   => 'left',
					__( 'Center', 'js_composer' ) => 'center',
					__( 'Right', 'js_composer' )  => 'right'
				),
				'group' 	 => __( 'Style', 'js_composer' )
			),
			array(
				'heading' 	  => __( 'Style', 'js_composer' ),
				'type' 		  => 'dropdown',
				'param_name'  => 'style',
				'value' 	  => array(
					__( 'Default', 'js_composer' )  => 'default',
					__( 'Classic', 'js_composer' )  => 'classic',
					__( 'Modern', 'js_composer' )   => 'modern',
					__( 'Special', 'js_composer' )  => 'special',
					__( 'Custom', 'js_composer' ) => 'custom'
				),
				'group' 	 => __( 'Style', 'js_composer' )
			),
			array(
				'type'        => 'colorpicker',
				'heading'     => __( 'Icon color', 'js_composer' ),
				'param_name'  => 'icon_color',
				'dependency'  => array( 'element' => 'style', 'value' => 'custom' ),
				'group' 	  => __( 'Style', 'js_composer' )
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Icon size', 'js_composer' ),
				'param_name'  => 'icon_size',
				'value'       => '',
				'dependency'  => array( 'element' => 'style', 'value' => 'custom' ),
				'group' 	  => __( 'Style', 'js_composer' )
			),
			array(
				'type'        => 'colorpicker',
				'heading'     => __( 'Separator color', 'js_composer' ),
				'param_name'  => 'separator_color',
				'dependency'  => array( 'element' => 'style', 'value' => 'custom' ),
				'group' 	  => __( 'Style', 'js_composer' )
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Title font size', 'js_composer' ),
				'param_name'  => 'title_font_size',
				'value'       => '',
				'dependency'  => array( 'element' => 'style', 'value' => 'custom' ),
				'group' 	  => __( 'Style', 'js_composer' )
			),
			array(
				'type'        => 'colorpicker',
				'heading'     => __( 'Title color', 'js_composer' ),
				'param_name'  => 'title_color',
				'dependency'  => array( 'element' => 'style', 'value' => 'custom' ),
				'group' 	  => __( 'Style', 'js_composer' )
			),
			array(
				'type' 		 => 'dropdown',
				'heading' 	 => __( 'Title font family', 'js_composer' ),
				'param_name' => 'title_font_family',
				'value' 	 => array(
					__( 'Default',  'js_composer' ) => 'default',
					__( 'Custom',   'js_composer' ) => 'custom'
				),
				'dependency' => array( 'element' => 'style', 'value' => 'custom' ),
				'group' 	 => __( 'Style', 'js_composer' )
			),
			array(
				'type' 		 => 'google_fonts',
				'param_name' => 'title_font',
				'value' 	 => '',
				'settings'   => array(
					'fields' => array(
						'font_family_description' => __( 'Select font family.', 'js_composer' ),
						'font_style_description'  => __( 'Select font styling.', 'js_composer' ),
					),
				),
				'dependency' => array( 'element' => 'title_font_family', 'value' => 'custom' ),
				'group' 	 => __( 'Style', 'js_composer' )
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Content font size', 'js_composer' ),
				'param_name'  => 'content_font_size',
				'dependency'  => array( 'element' => 'style', 'value' => 'custom' ),
				'group' 	  => __( 'Style', 'js_composer' )
			),
			array(
				'type'        => 'colorpicker',
				'heading'     => __( 'Content color', 'js_composer' ),
				'param_name'  => 'content_color',
				'dependency'  => array( 'element' => 'style', 'value' => 'custom' ),
				'group' 	 => __( 'Style', 'js_composer' )
			),
			array(
				'type' 		 => 'dropdown',
				'heading' 	 => __( 'Content font family', 'js_composer' ),
				'param_name' => 'content_font_family',
				'value' 	 => array(
					__( 'Default',  'js_composer' ) => 'default',
					__( 'Custom',   'js_composer' ) => 'custom'
				),
				'dependency' => array( 'element' => 'style', 'value' => 'custom' ),
				'group' 	 => __( 'Style', 'js_composer' )
			),
			array(
				'type' 		 => 'google_fonts',
				'param_name' => 'content_font',
				'value' 	 => '',
				'settings'   => array(
					'fields' => array(
						'font_family_description' => __( 'Select font family.', 'js_composer' ),
						'font_style_description'  => __( 'Select font styling.', 'js_composer' ),
					),
				),
				'dependency' => array( 'element' => 'content_font_family', 'value' => 'custom' ),
				'group' 	 => __( 'Style', 'js_composer' )
			),
			/* CSS editor */
			array(
				'type' 		  => 'css_editor',
				'heading' 	  => __( 'CSS box', 'js_composer' ),
				'param_name'  => 'css',
				'group' 	  => __( 'Design options', 'js_composer' )
			)
		)
	)
);

class WPBakeryShortCode_antica_icon_text extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
		    'title' 			  => '',
		    'icon' 				  => '',
		    'icon_flaticon'       => 'icon-adjustments',
		    'icon_ion'            => '',
		    'text' 				  => '',
		    'icon_type' 		  => 'faw',
		    'seperator_item'      => false,
		    'style_color' 		  => 'dark',
		    'el_class' 			  => '',
		    'align' 			  => 'left',
		    'style' 			  => 'default',
		    'icon_color' 		  => '',
		    'icon_size' 		  => '',
		    'title_font_size' 	  => '',
		    'title_color' 		  => '',
		    'title_font_family'   => 'default',
		    'title_font' 		  => '',
		    'content_font_size'   => '',
		    'content_color' 	  => '',
		    'content_font_family' => 'default',
		    'content_font' 		  => '',
		    'css' 				  => ''
		), $atts ) );


		$class  = ( ! empty( $el_class ) ) ? $el_class : '';
		$class .= vc_shortcode_custom_css_class( $css, ' ' );
		$class .= ( $style != 'custom' ) ? ' ' . $style : '';

		$title_style     = '';
		$content_style   = '';

		/* Custom shortcode styles */
		if( $style == 'custom' ) {
			$google_fonts = new Vc_Google_Fonts;
			
			/* Title style */
			if( ! empty( $title_font_size ) ) {
				$title_style = ( is_numeric( $title_font_size ) ) ? 'font-size: ' . $title_font_size . 'px;' : 'font-size: ' . $title_font_size . ';'; 
			}
			$title_style .= ( ! empty( $title_color ) ) ? 'color: ' . $title_color . ';' : '';
			
			if( $title_font_family == 'custom' ) {

				$title_font = $google_fonts->_vc_google_fonts_parse_attributes( $atts, $title_font );

				$subsets  = '';
				$settings = get_option( 'wpb_js_google_fonts_subsets' );
				if ( is_array( $settings ) && ! empty( $settings ) ) {
					$subsets = '&subset=' . implode( ',', $settings );
				}

				wp_enqueue_style( 'vc_google_fonts_' . vc_build_safe_css_class( $title_font['values']['font_family'] ), '//fonts.googleapis.com/css?family=' . $title_font['values']['font_family'] . $subsets );
				
				$title_font = explode( ':', $title_font['values']['font_family'] );
				
				$title_style .= 'font-family: ' . $title_font[0] . ';';
			}

			/* Content style */
			if( ! empty( $content_font_size ) ) {
				$content_style = ( is_numeric( $content_font_size ) ) ? 'font-size: ' . $content_font_size . 'px;' : 'font-size: ' . $content_font_size . ';'; 
			}
			$content_style .= ( ! empty( $content_color ) ) ? 'color: ' . $content_color . ';' : '';

			if( $content_font_family == 'custom' ) {

				$content_font = $google_fonts->_vc_google_fonts_parse_attributes( $atts, $content_font );

				$subsets  = '';
				$settings = get_option( 'wpb_js_google_fonts_subsets' );
				if ( is_array( $settings ) && ! empty( $settings ) ) {
					$subsets = '&subset=' . implode( ',', $settings );
				}

				wp_enqueue_style( 'vc_google_fonts_' . vc_build_safe_css_class( $content_font['values']['font_family'] ), '//fonts.googleapis.com/css?family=' . $content_font['values']['font_family'] . $subsets );
				
				$content_font = explode( ':', $content_font['values']['font_family'] );
				
				$content_style .= 'font-family: ' . $content_font[0] . ';';
			}

			$content_style   = ( ! empty( $content_style ) )   ? 'style="' . $content_style . '"' : '';
			$title_style     = ( ! empty( $title_style ) )     ? 'style="' . $title_style . '"' : '';
		}

		// Icon type
		if( $icon_type == 'faw' ) {
			$icon = $icon;
		} else {
			$icon = $icon_ion;
		}

		// Style color
		$style_color = ( isset( $style_color ) && $style_color == 'dark' ) ? 'dark' : $style_color;
		
		// Seperator item 
		$seperator_item = ( isset( $seperator_item ) && $seperator_item == 'true' ) ? 'seperator' : '';

		$output = '<div class="featured-item text-' . $align . ' ' . $class . ' ' . $style_color . ' ' . $seperator_item . '">';

			if( ! empty( $icon ) ) {
				$output .= '<i class="' . $icon . '"></i>';
			}
			/* Title */
			if( ! empty( $title ) ) {
				$output .= '<h2 ' . $title_style . '>' . $title . '</h2>';
			}
			/* Text */
			if( ! empty( $text ) ) {
				$output .= '<div ' . $content_style . '><p>' . $text . '</p></div>';
			}
		
		$output .= '</div>';

		return  $output;
	}
}