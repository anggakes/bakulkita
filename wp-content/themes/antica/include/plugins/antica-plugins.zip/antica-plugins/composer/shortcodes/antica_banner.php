<?php 
/*
 * Banner Shortcode
 * Author: QodeArena
 * Author URI: http://qodearena.com/
 * Version: 1.0.0 
 */

vc_map(
	array(
		'name'        => __( 'Banner', 'js_composer' ),
		'base'        => 'antica_banner',
		'params'      => array(
			array(
				'heading' 	  => __( 'Banner style', 'js_composer' ),
				'type' 		  => 'dropdown',
				'param_name'  => 'banner_style',
				'value' 	  => array(
					__( 'Default', 'js_composer' )    => 'default',
					__( 'Modern', 'js_composer' )     => 'modern',
				)
			),
			array(
				'type'        => 'textarea',
				'heading'     => __( 'Title', 'js_composer' ),
				'param_name'  => 'title',
			),
			array(
				'heading' 	  => __( 'Title tag', 'js_composer' ),
				'type' 		  => 'dropdown',
				'param_name'  => 'title_tag',
				'value' 	  => array(
					__( 'H2', 'js_composer' ) => 'h2',
					__( 'H3', 'js_composer' ) => 'h3',
					__( 'H4', 'js_composer' ) => 'h4',
					__( 'H5', 'js_composer' ) => 'h5',
					__( 'H6', 'js_composer' ) => 'h6',
					__( 'P', 'js_composer' )  => 'p',
				),
			),
			array(
				'type' 		  => 'textarea',
				'heading'     => __( 'Content', 'js_composer' ),
				'param_name'  => 'subtitle',
				'value' 	  => '',
				'dependency' => array( 'element' => 'banner_style', 'value' => 'default' )
			),
			array(
				'type'        => 'attach_image',
				'heading'     => __( 'Image', 'js_composer' ),
				'param_name'  => 'image',
			),
			array(
				'heading' 	  => __( 'Link', 'js_composer' ),
				'type' 		  => 'vc_link',
				'param_name'  => 'link',
				'value' 	  => '',
				'dependency' => array( 'element' => 'banner_style', 'value' => 'modern' )
			),
			array(
				'heading' 	  => __( 'Hide / Show Breadcrumb', 'js_composer' ),
				'type' 		  => 'dropdown',
				'param_name'  => 'hide_breadcrumb',
				'value' 	  => array(
					__( 'Hide', 'js_composer' ) => 'hide',
					__( 'Show', 'js_composer' ) => 'show',
				),
				'dependency' => array( 'element' => 'banner_style', 'value' => 'default' )
			),
			array(
				'type' 		  => 'textfield',
				'heading' 	  => __( 'Extra class name', 'js_composer' ),
				'param_name'  => 'el_class',
				'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
				'value' 	  => ''
			),
			/* Style tab */
			array(
				'heading' 	  => __( 'Block align', 'js_composer' ),
				'type' 		  => 'dropdown',
				'param_name'  => 'align',
				'value' 	  => array(
					__( 'Center', 'js_composer' ) => 'center',
					__( 'Left', 'js_composer' )   => 'left',
					__( 'Right', 'js_composer' )  => 'right'
				),
				'group' 	 => __( 'Style', 'js_composer' )
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Title font size', 'js_composer' ),
				'param_name'  => 'title_font_size',
				'value'       => '',
				'group' 	  => __( 'Style', 'js_composer' )
			),
			array(
				'type'        => 'colorpicker',
				'heading'     => __( 'Title color', 'js_composer' ),
				'param_name'  => 'title_color',
				'group' 	  => __( 'Style', 'js_composer' )
			),
			array(
				'type' 		 => 'dropdown',
				'heading' 	 => __( 'Title font family', 'js_composer' ),
				'param_name' => 'title_font_family',
				'value' 	 => array(
					__( 'Default',  'js_composer' ) => 'default',
					__( 'Custom',   'js_composer' ) => 'custom'
				),
				'group' 	 => __( 'Style', 'js_composer' )
			),
			array(
				'type' 		 => 'google_fonts',
				'param_name' => 'title_font',
				'value' 	 => '',
				'settings'   => array(
					'fields' => array(
						'font_family_description' => __( 'Select font family.', 'js_composer' ),
						'font_style_description'  => __( 'Select font styling.', 'js_composer' ),
					),
				),
				'dependency' => array( 'element' => 'title_font_family', 'value' => 'custom' ),
				'group' 	 => __( 'Style', 'js_composer' )
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Content font size', 'js_composer' ),
				'param_name'  => 'content_font_size',
				'value'       => '',
				'group' 	  => __( 'Style', 'js_composer' )
			),
			array(
				'type'        => 'colorpicker',
				'heading'     => __( 'Content color', 'js_composer' ),
				'param_name'  => 'content_color',
				'group' 	  => __( 'Style', 'js_composer' )
			),
			array(
				'type' 		 => 'dropdown',
				'heading' 	 => __( 'Content font family', 'js_composer' ),
				'param_name' => 'content_font_family',
				'value' 	 => array(
					__( 'Default',  'js_composer' ) => 'default',
					__( 'Custom',   'js_composer' ) => 'custom'
				),
				'group' 	 => __( 'Style', 'js_composer' )
			),
			array(
				'type' 		 => 'google_fonts',
				'param_name' => 'content_font',
				'value' 	 => '',
				'settings'   => array(
					'fields' => array(
						'font_family_description' => __( 'Select font family.', 'js_composer' ),
						'font_style_description'  => __( 'Select font styling.', 'js_composer' ),
					),
				),
				'dependency' => array( 'element' => 'position_font_family', 'value' => 'custom' ),
				'group' 	 => __( 'Style', 'js_composer' )
			),
			/* CSS editor */
			array(
				'type' 		  => 'css_editor',
				'heading' 	  => __( 'CSS box', 'js_composer' ),
				'param_name'  => 'css',
				'group' 	  => __( 'Design options', 'js_composer' )
			)
		)
	)
);

class WPBakeryShortCode_antica_banner extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'banner_style' 	      => 'default',
			'title' 			  => '',
			'title_tag' 		  => 'h2',
			'subtitle' 			  => '',
			'image' 			  => '',
			'link'                => '',
			'hide_breadcrumb'     => 'hide',
			'el_class' 			  => '',
			'align' 			  => 'center',
			'title_font_size' 	  => '',
			'title_color' 		  => '',
			'title_font_family'   => 'default',
			'title_font' 		  => '',
			'content_font_size'   => '',
			'content_color' 	  => '',
			'content_font_family' => 'default',
			'content_font' 		  => '',
			'css' 		 		  => ''
		), $atts ) );

		$google_fonts = new Vc_Google_Fonts;

		$class  = ( ! empty( $el_class ) ) ? $el_class : '';
		$class .= vc_shortcode_custom_css_class( $css, ' ' );
		$class .= ' text-' . $align;

		$image 	= ( ! empty( $image ) && is_numeric( $image ) ) ? wp_get_attachment_url( $image ) : ''; 

		$title_style   = '';
		$content_style = '';
		$styles = array( 'title', 'content' );

		?> <?php $breadcrumbs = antica_breadcrumbs() ?>
		<?php 

		foreach ( $styles as $item ) {

			if( ! empty( ${$item."_font_size"} ) ) {
				${$item."_style"} = ( is_numeric( ${$item."_font_size"} ) ) ? 'font-size: ' . ${$item."_font_size"} . 'px;' : 'font-size: ' . ${$item."_font_size"} . ';'; 
			}
			${$item."_style"} .= ( ! empty( ${$item."_color"} ) ) ? 'color: ' . ${$item."_color"} . ';' : '';

			if( ${$item."_font_family"} == 'custom' ) {
				${$item."_font"} = $google_fonts->_vc_google_fonts_parse_attributes( $atts, ${$item."_font"} );

				$subsets  = '';
				$settings = get_option( 'wpb_js_google_fonts_subsets' );
				if ( is_array( $settings ) && ! empty( $settings ) ) {
					$subsets = '&subset=' . implode( ',', $settings );
				}

				wp_enqueue_style( 'vc_google_fonts_' . vc_build_safe_css_class( ${$item."_font"}['values']['font_family'] ), '//fonts.googleapis.com/css?family=' . ${$item."_font"}['values']['font_family'] . $subsets );
				
				${$item."_font"} = explode( ':', ${$item."_font"}['values']['font_family'] );
				
				${$item."_style"} .= 'font-family: ' . ${$item."_font"}[0] . ';';
			}

			${$item."_style"} = ( ! empty( ${$item."_style"} ) ) ? 'style="' . ${$item."_style"} . '"' : '';

		}

		$title = ( ! empty( $title ) ) ? '<' . $title_tag . ' ' . $title_style . ' class="title">' . $title . '</' . $title_tag . '>' : '';
		$subtitle  = ( ! empty( $subtitle ) ) ? '<span class="subtitle" ' . $content_style . '>' . $subtitle . '</span>' : '';
		$banner_link = vc_build_link( $link );
		$banner_link_target = ( ! empty( $banner_link['target'] ) ) ? 'target="' . $banner_link['target'] . '"' : ''; 
		$button = ( ! empty( $banner_link['url'] ) ) ? '<a href="' . $banner_link['url'] . '" class="link" ' . $banner_link_target . '>' . $banner_link['title'] . '</a>' : '';
		$output = '';

		if( $banner_style == 'default' ) {
			$output .= '<div class="banner-page ' . $class . ' ' . $banner_style . '">';
				$output .= '<img src="' . $image . '" class="hidden img-post" alt="">';
				$output .= '<div class="container">';
	                $output .= '<div class="content-title">';
	                    $output .= $title;
	                    $output .= $subtitle;
	                $output .= '</div>';

	                if( isset( $hide_breadcrumb ) && $hide_breadcrumb == 'show' ) {
						$output .= '<ul class="breadcrumb clearfix">';
						$output .= $breadcrumbs;
						$output .= '</ul>';
					}
	        	$output .= '</div>';
	        $output .= '</div>';
		} else {
			$output .= '<div class="banner-page ' . $banner_style . '">';
				$output .= '<div class="overflow"></div>';
	            $output .= '<img src="' . $image . '" class="hidden img-post" alt="">';
	            $output .= '<div class="content-banner">';
	                $output .= '<div class="container-fluid">';
	                    $output .= '<div class="row">';
	                        $output .= '<div class="col-md-8 col-md-offset-2">';
		                        $output .= $title;
		                        $output .= $button;
	                        $output .= '</div>';
	                    $output .= '</div>';
	                $output .= '</div>';
	            $output .= '</div>';
        	$output .= '</div>';
		}

		return $output;
	}
}