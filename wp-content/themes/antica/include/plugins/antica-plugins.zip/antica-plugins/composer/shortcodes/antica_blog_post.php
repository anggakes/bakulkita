<?php 
/*
 * Blog Post Shortcode
 * Author: QodeArena
 * Author URI: http://qodearena.com/
 * Version: 1.0.0 
 */

vc_map( 
	array(
		'name'            => __( 'Blog', 'js_composer' ),
		'base'            => 'antica_blog',
		'description'     => __( 'Posts list', 'js_composer' ),
		'params'          => array(
			array(
				'heading' 	  => __( 'Style blog', 'js_composer' ),
				'type' 		  => 'dropdown',
				'param_name'  => 'style_blog',
				'value' 	  => array(
					__( 'Default', 'js_composer' )  => 'default',
					__( 'Modern', 'js_composer' )   => 'modern',
				)
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Title', 'js_composer' ),
				'param_name'  => 'title',
				'admin_label' => true,
				'value'       => ''
			),
			array(
				'heading' 	  => __( 'Title tag', 'js_composer' ),
				'type' 		  => 'dropdown',
				'param_name'  => 'title_tag',
				'value' 	  => array(
					__( 'H2', 'js_composer' ) => 'h2',
					__( 'H3', 'js_composer' ) => 'h3',
					__( 'H4', 'js_composer' ) => 'h4',
					__( 'H5', 'js_composer' ) => 'h5',
					__( 'H6', 'js_composer' ) => 'h6',
					__( 'P', 'js_composer' )  => 'p',
				)
			),
			array(
				'heading' 	  => __( 'Title align', 'js_composer' ),
				'type' 		  => 'dropdown',
				'param_name'  => 'title_align',
				'value' 	  => array(
					__( 'Center', 'js_composer' ) => 'center',
					__( 'Left', 'js_composer' )   => 'left',
					__( 'Right', 'js_composer' )  => 'right',
				)
			),
			array(
				'type'        => 'vc_efa_chosen',
				'heading'     => __( 'Custom Categories', 'js_composer' ),
				'param_name'  => 'categories',
				'placeholder' => 'Choose category (optional)',
				'value'       => antica_param_values( 'categories' ),
				'std'         => '',
				'admin_label' => true,
				'description' => __( 'You can choose spesific categories for blog, default is all categories', 'js_composer' ),
			),
			array(
				'type' 		  => 'dropdown',
				'heading' 	  => 'Order by',
				'param_name'  => 'orderby',
				'admin_label' => true,
				'value' 	  => array(
					'ID' 		    => 'ID',
					'Author' 	    => 'author',
					'Post Title'    => 'title',
					'Date' 		    => 'date',
					'Last Modified' => 'modified',
					'Random Order'  => 'rand',
					'Menu Order'    => 'menu_order'
				)
			),
			array(
				'type' 		  => 'dropdown',
				'heading' 	  => 'Order type',
				'param_name'  => 'order',
				'value' 	  => array(
					'Ascending'  => 'ASC',
					'Descending' => 'DESC'
				)
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Count items', 'js_composer' ),
				'param_name'  => 'limit',
				'value'       => '',
				'admin_label' => true,
				'description' => __( 'Default 10 items.', 'js_composer' )
			),
			array(
				'type' 		  => 'textfield',
				'heading' 	  => __( 'Extra class name', 'js_composer' ),
				'param_name'  => 'el_class',
				'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
				'value' 	  => ''
			),
			array(
				'type' 		  => 'css_editor',
				'heading' 	  => __( 'CSS box', 'js_composer' ),
				'param_name'  => 'css',
				'group' 	  => __( 'Design options', 'js_composer' )
			)
		)
	)
);

class WPBakeryShortCode_antica_blog extends WPBakeryShortCode{

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'style_blog'   => 'default',
			'title' 	   => '',
			'title_tag'    => 'h2',
			'title_align'  => 'center',
			'categories'   => '',
			'orderby' 	   => 'ID',
			'order' 	   => 'ASC',
			'limit' 	   => '',
			'el_class' 	   => '',
			'css' 		   => ''
		), $atts ) );

	/* Custom styles */

		$class  	= ( ! empty( $el_class ) ) ? $el_class : '';
		$class 	   .= vc_shortcode_custom_css_class( $css, ' ' );

	/* FOR BLOG CONTENT */

		// get $categories
		if ( empty( $categories ) ){
			// get all category potfolio
			$categories = array();
			$terms = get_categories();
			foreach($terms as $term){
				$categories[] = $term->slug;
			}
		} else {
			$categories = explode( ',', $categories );
		}

		// params output
		$args = array(
			'posts_per_page' => $limit,
			'post_type'   	 => 'post',
			'orderby'   	 => $orderby,
			'order'   		 => $order,
			'tax_query' 	 => array(
				array(
					'taxonomy'  => 'category',
					'field'     => 'slug',
					'terms'     => $categories
				)
			)
		);

		// get blog posts
		$post = new WP_Query( $args );

		// start output
		ob_start(); ?>

		<div class="blog_body_items">
			<?php while ( $post->have_posts() ) : $post->the_post(); 

			$terms = get_the_terms( $post->ID , 'category' );

			// add attribute item
			$post_slug_category = '';
			$post_item_attr 	= '';
			foreach ($terms as $term) {
				$post_slug_category .= ' ' . $term->slug;
				$post_item_attr 	.= ' ' . $term->slug;
			}

			if( $style_blog == 'default' ) { ?>
				<div class="blog_item">
	        		<?php if( has_post_thumbnail() ) { ?>
	                	<div class="post-bg">
								<?php the_post_thumbnail( 'full', array('class'=>'hidden img-post') ); ?>
	                	</div>
					<?php } ?>
	                <span class="blog_date"><?php the_time( get_option('date_format') ); ?></span>
	                <a href="<?php the_permalink(); ?>">
	                <h3><?php the_title(); ?></h3>
	                </a>
	                <span class="blog_coment"><?php esc_html_e( ' Comments', 'antica' ); ?> <?php echo esc_html( $post->comment_count ); ?></span>
	            </div>
			<?php } else { ?>
				<div class="blog-item-modern">
					<div class="blog-content-modern">
		                <span class="blog_date"><?php the_time( get_option('date_format') ); ?></span>
		                <a href="<?php the_permalink(); ?>">
		                <h3><?php the_title(); ?></h3>
		                </a>
		                <span class="blog_coment"><?php esc_html_e( ' Comments', 'antica' ); ?> <?php echo esc_html( $post->comment_count ); ?></span>
					</div>
	        		<?php if( has_post_thumbnail() ) { ?>
	                	<div class="post-bg">
								<?php the_post_thumbnail( 'full' ); ?>
	                	</div>
					<?php } ?>
	            </div>
			<?php } ?>


			<?php  endwhile; wp_reset_postdata(); ?>

		</div>

		<?php return ob_get_clean();
		
	} // end function content

	
}
