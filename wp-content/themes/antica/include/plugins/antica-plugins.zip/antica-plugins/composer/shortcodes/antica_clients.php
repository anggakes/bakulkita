<?php 
/*
 * Clients Shortcode
 * Author: QodeArena
 * Author URI: https://themeforest.net/user/qodearena
 * Version: 1.0.0 
 */

vc_map( 
	array(
		'name'                    => __( 'Clients', 'js_composer' ),
		'base'                    => 'antica_clients',
		'content_element'         => true,
		'show_settings_on_create' => true,
		'params' => array(
			array(
				'type'       => 'param_group',
				'heading'    => __( 'Logos', 'js_composer' ),
				'param_name' => 'items',
				'params'     => array(
					array(
						'type'        => 'attach_image',
						'heading'     => __( 'Image', 'js_composer' ),
						'param_name'  => 'image'
					),
					array(
						'type' 		 => 'vc_link',
						'heading' 	 => __( 'Logo link', 'js_composer' ),
						'param_name' => 'logo_link',
					),
				),
				'callbacks' => array(
					'after_add' => 'vcChartParamAfterAddCallback'
				)
			),
			array(
				'type'        => 'dropdown',
				'heading'     => __( 'Item columns size', 'js_composer' ),
				'param_name'  => 'columns',
				'value'       => array(
					'5 columns' => '1/5',
					'4 columns' => '1/4',
					'3 columns' => '1/3',
					'2 columns' => '1/2',
				)
			),
			array(
				'type' 		  => 'textfield',
				'heading' 	  => __( 'Extra class name', 'js_composer' ),
				'param_name'  => 'el_class',
				'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
				'value' 	  => ''
			),
			array(
				'type' 		  => 'css_editor',
				'heading' 	  => __( 'CSS box', 'js_composer' ),
				'param_name'  => 'css',
				'group' 	  => __( 'Design options', 'js_composer' )
			)
		) //end params
	)
);

class WPBakeryShortCode_antica_clients extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'items'    => '',
			'columns'  => '1/5',
			'el_class' => '',
			'css' 	   => ''
		), $atts ) );

		$output = '';
		$items 	= json_decode( urldecode( $items ), true );
		$class  = ( ! empty( $el_class ) ) ? $el_class : '';
		$class 	.= vc_shortcode_custom_css_class( $css, ' ' );

		if ( function_exists('wpb_translateColumnWidthToSpan') ) {
			if( $columns == '1/5' ) {
				$width_class = 'col-5';
			} else {
				$width_class = wpb_translateColumnWidthToSpan( $columns );
			}
		}
		
		if( ! empty( $items ) ) {

			$output .= '<div class="' . $class . '">';

				foreach ( $items as $item ) {

					$image 	= ( ! empty( $item['image'] ) && is_numeric( $item['image'] ) ) ? wp_get_attachment_url( $item['image'] ) : '';

	                if( ! empty( $image ) ) {

	                	// Link image client
	                	$link_image = ( ! empty( $item['logo_link'] ) ) ? $item['logo_link'] : '';
						$link = vc_build_link( $link_image );

						// Image client
						$logo = '<img src="' . $image . '" alt=""/>';

						$output .= '<div class="labels_item ' . $width_class . '">';
						if( ! empty( $link['url'] ) ) {
							$link_target = ( ! empty( $link['target'] ) ) ? 'target="' . $link['target'] . '"' : ''; 
							$output .= '<a href=' . $link['url'] . ' ' . $link_target . '>';
							$output .= $logo;
							$output .= '</a>';
						} else {
							$output .= $logo;
						}
						$output .= '</div>';
					}
	            }    
            $output .= '</div>';

			return $output;
		}
	}
}