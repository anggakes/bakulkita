<?php 
/*
 * Banner Shortcode
 * Author: QodeArena
 * Author URI: http://qodearena.com/
 * Version: 1.0.0 
 */

vc_map( array(
	'name'            => __( 'Portfolio', 'js_composer' ),
	'base'            => 'antica_portfolio',
	'description'     => __( 'Portfolio list', 'js_composer' ),
	'params'          => array(
		array(
			'type'        => 'vc_efa_chosen',
			'heading'     => __( 'Custom Categories', 'js_composer' ),
			'param_name'  => 'categories',
			'placeholder' => 'Choose category (optional)',
			'value'       => antica_param_values( 'terms' ),
			'std'         => '',
			'admin_label' => true,
			'description' => __( 'You can choose spesific categories for blog, default is all categories', 'js_composer' ),
		),
		array(
			'type' 		  => 'dropdown',
			'heading' 	  => 'Order by',
			'param_name'  => 'orderby',
			'admin_label' => true,
			'value' 	  => array(
				'ID' 		    => 'ID',
				'Author' 	    => 'author',
				'Post Title'    => 'title',
				'Date' 		    => 'date',
				'Last Modified' => 'modified',
				'Random Order'  => 'rand',
				'Menu Order'    => 'menu_order'
			)
		),		
		array(
			'type' 		  => 'dropdown',
			'heading' 	  => 'Order type',
			'param_name'  => 'order',
			'value' 	  => array(
				'Ascending'  => 'ASC',
				'Descending' => 'DESC'
			)
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Count items', 'js_composer' ),
			'param_name'  => 'limit',
			'value'       => '',
			'admin_label' => true,
			'description' => __( 'Default 10 items.', 'js_composer' )
		),
		/* Portfolio style */
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Style', 'js_composer' ),
			'param_name'  => 'style',
			'value'       => array(
				'Style 1' => 'works_body',
				'Style 2' => 'two_column',
			),
			'group' 	  => 'Portfolio style'
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Count columns', 'js_composer' ),
			'param_name'  => 'columns',
			'value'       => array(
				'4 columns'  => '1/4',
				'3 columns'  => '1/3',
				'2 columns'  => '1/2',
			),
			'group' 	  => 'Portfolio style'
		),
		array(
			'type' => 'animation_style',
			'heading' => __( 'Animation In', 'js_composer' ),
			'param_name' => 'paging_animation_in',
			'group' 	  => 'Portfolio style',
			'settings' => array(
				'type' => array(
					'in',
					'other',
				),
			),
		),

		/* Filter settings */
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Filter', 'js_composer' ),
			'param_name'  => 'filter_style',
			'value'       => array(
				'Hidden'  	=> 'hidden',
				'Show'  	=> 'show'
			),
			'group' 	  => 'Filter settings'
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Align', 'js_composer' ),
			'param_name'  => 'filter_align',
			'value'       => array(
				'Left'  	=> 'left',
				'Center'  	=> 'center',
				'Right'  	=> 'right'
			),
			'dependency'  => array( 'element' => 'filter_style', 'value' => 'show' ),
			'group' 	  => 'Filter settings'
		),
	)
));




class WPBakeryShortCode_antica_portfolio extends WPBakeryShortCode{

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'categories' 			  => '',
			'orderby' 				  => 'ID',
			'order' 				  => 'ASC',
			'limit' 				  => '',
			'columns' 				  => '1/4',
			'style' 				  => 'works_body',
			'filter_style' 			  => 'hidden',
			'filter_align' 			  => 'left'
		), $atts ) );


	/* FOR PORTFOLIO  FILTERS */
		$limit = ( ! empty( $limit ) && is_numeric( $limit ) ) ? $limit : 10;
		
		// add filter align
		$filter_styles = ' text-' . $filter_align;

		// bootstrap width column
		$width_class = 'col-md-6';
		if ( function_exists('wpb_translateColumnWidthToSpan') ) {
			$width_class = wpb_translateColumnWidthToSpan( $columns );
		}


	/* FOR PORTFOLIO  CONTENT */

		// get $categories
		if ( empty($categories) ){
			// get all category potfolio
			$categories = array();
			$terms = get_terms('portfolio-category', 'orderby=name&hide_empty=0');
			foreach($terms as $term){
				$categories[] = $term->slug;
			}
		} else {
			$categories = explode( ',', $categories );
		}

		$post_item_attr = (!empty($animation)) ? ' ' . $animation : '';

		// animation 
		$animation = (! empty($animation) ) ? ' animated '.$animation : ' wow fadeInUpBig';

		// params output
		$args = array(
			'posts_per_page' => $limit,
			'post_type'   	 => 'portfolio',
			'orderby'   	 => $orderby,
			'order'   		 => $order,
			'tax_query' 	 => array(
				array(
					'taxonomy'  => 'portfolio-category',
					'field'     => 'slug',
					'terms'     => $categories
				)
			)
		);

		// get portfolio posts
		$portfolio = new WP_Query( $args );

		// start output
		ob_start(); ?>

		<div class="<?php echo esc_attr( $style ); ?>">
			<?php if( $filter_style != 'hidden' ) { ?>
				<div class="col-md-3">
					<div id="filters" class="fillter_wrap <?php echo esc_attr( $filter_styles );?>">
		                <a href="#" class="but activbut" data-filter="*"><?php echo esc_html__('Show All', 'antica' ); ?></a>    
		                <?php foreach ( $categories as $category_slug ) { 
							$category = get_term_by('slug', $category_slug, 'portfolio-category'); ?>
		                	<a href="#" class="but" data-filter=".<?php echo esc_html( $category->slug ); ?>"><?php echo esc_html( $category->name ); ?></a>
						<?php } ?>
		            </div>
				</div>
			<?php } ?>
			
			<div class="col-md-9">
				<div class="izotope_container">
					<?php while ( $portfolio->have_posts() ) : $portfolio->the_post(); 
						  setup_postdata( $portfolio );

					$terms = get_the_terms( $portfolio->ID , 'portfolio-category' );
					// add attribute item
					$post_slug_category = array();
					$post_item_attr = '';
					foreach ($terms as $term) {
						$post_slug_category[] = $term->name;
						$post_item_attr .= ' ' . $term->slug;
					} 

					?>
					<div class="izotope_item item-<?php echo the_ID(); ?> <?php echo esc_attr( $width_class ); ?> <?php echo esc_attr( $post_item_attr  ); ?>">
						<div class="item_show"><a href="<?php echo get_the_post_thumbnail_url(null, 'full');?>"><?php the_post_thumbnail( 'full', array('class'=>'bg-responsive-img') ); ?></a></div>
                        <?php if( $style == 'two_column' ) : ?>
	                        <div class="item_hide">
	                        	<a href="<?php echo get_the_post_thumbnail_url(null, 'full');?>">
	                                <i class='icon-search'></i>
	                                <h3><?php the_title(); ?></h3>
	                                <span><?php echo esc_html( strtoupper( implode( ', ', $post_slug_category ) ) ); ?></span>
	                            </a>
	                        </div>
                        <?php endif; ?>
					</div>
					<?php  endwhile; wp_reset_postdata(); ?>

				</div>
			</div>
		</div>

		<?php return ob_get_clean();
		
	} // end function content

	
}
